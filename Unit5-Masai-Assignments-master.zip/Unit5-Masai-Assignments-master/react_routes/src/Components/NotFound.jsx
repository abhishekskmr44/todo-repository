import React from 'react'
import '../App.css'

export const NotFound = () => {
    return (
        <div className='notFoundContainer'>
            <p>Page not found</p>
        </div>
    )
}
