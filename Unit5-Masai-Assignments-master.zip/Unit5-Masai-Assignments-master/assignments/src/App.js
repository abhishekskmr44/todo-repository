import './App.css';
import { SampleTimer } from './Components/SampleTimer';

function App() {
  return (
    <div className="Container">
      <SampleTimer />
    </div>
  );
}

export default App;
