import React from 'react'
import { Posts } from '../components/Posts';

export const Home = () => {
    return (
        <div className='homeContainer'>
            <Posts />
        </div>
    )
}
