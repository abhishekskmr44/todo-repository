import React from 'react'
import '../App.css'

export const Users = () => {
    return (
        <div className='homeContainer'>
            <p>No users to display</p>
        </div>
    )
}
