export const GET_POSTS = "GET_POSTS";
export const DELETE_TODOS = "DELETE_TODOS";