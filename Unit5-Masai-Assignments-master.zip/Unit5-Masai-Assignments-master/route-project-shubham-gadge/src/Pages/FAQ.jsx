import React from 'react'

export const FAQ = () => {
    return (
        <div>FAQ</div>
    )
}
