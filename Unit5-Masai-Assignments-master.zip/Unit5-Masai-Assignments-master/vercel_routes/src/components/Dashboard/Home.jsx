import React from 'react'
import "../CSS/Home.css"

export const Home = () => {
    return (
        <div className='homeContainer'>
            <h3>Home</h3>
            <h1>Welcome to Products</h1>
        </div>
    )
}
