import React from 'react'
import "../CSS/About.css"

export const About = () => {
    return (
        <div className='aboutContainer'>
            <h3>About</h3>
            <h1>Welcome to Products</h1>
        </div>
    )
}
